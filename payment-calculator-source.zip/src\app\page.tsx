'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import PaymentForm from '@/components/PaymentForm';
import InstallmentsTable from '@/components/InstallmentsTable';
import SummarySection from '@/components/SummarySection';
import ResultSection from '@/components/ResultSection';

export interface PaymentData {
  referenceValue: number | string;
  paymentMethod: string;
  installments: number;
  entryDate: string;
  downPayment: number;
  discount: number;
  installmentInterval: number;
  firstInstallmentTerm: number;
  dueDay: number;
}

export interface Installment {
  id: string;
  description: string;
  value: number;
  dueDate: string;
  paymentMethod: string;
}

export interface Summary {
  subtotal: number;
  financialDiscount: number;
  total: number;
}

export default function Home() {
  const [paymentData, setPaymentData] = useState<PaymentData>({
    referenceValue: 0,
    paymentMethod: 'PARCELADO',
    installments: 0,
    entryDate: new Date().toISOString().split('T')[0],
    downPayment: 100,
    discount: 0,
    installmentInterval: 30,
    firstInstallmentTerm: 0,
    dueDay: 0,
  });

  const [installments, setInstallments] = useState<Installment[]>([]);
  const [summary, setSummary] = useState<Summary>({
    subtotal: 0,
    financialDiscount: 0,
    total: 0,
  });
  const [resultText, setResultText] = useState<string>('');
  const [showResult, setShowResult] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Função para formatar moeda brasileira
  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Função para formatar data brasileira
  const formatDateBR = (dateString: string): string => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  // Função para gerar parcelas
  const generateInstallments = useCallback((total: number, cashValue: number) => {
    const newInstallments: Installment[] = [];

    // Adicionar entrada à vista
    if (paymentData.downPayment > 0) {
      newInstallments.push({
        id: 'cash',
        description: 'À vista',
        value: cashValue,
        dueDate: paymentData.entryDate,
        paymentMethod: 'Boleto',
      });
    }

    // Adicionar parcelas se necessário
    if (paymentData.installments > 0) {
      const remainingValue = total - cashValue;
      const installmentValue = remainingValue / paymentData.installments;

      for (let i = 1; i <= paymentData.installments; i++) {
        const dueDate = new Date();
        dueDate.setDate(
          dueDate.getDate() + 
          paymentData.firstInstallmentTerm + 
          (i * paymentData.installmentInterval)
        );

        newInstallments.push({
          id: `installment-${i}`,
          description: `${i}ª parcela`,
          value: installmentValue,
          dueDate: dueDate.toISOString().split('T')[0],
          paymentMethod: 'Boleto',
        });
      }
    }

    setInstallments(newInstallments);
  }, [paymentData.downPayment, paymentData.entryDate, paymentData.installments, paymentData.firstInstallmentTerm, paymentData.installmentInterval]);

  // Função para calcular pagamento
  const calculatePayment = useCallback(() => {
    // Converter referenceValue para número se for string
    let subtotal = 0;
    if (typeof paymentData.referenceValue === 'string') {
      subtotal = parseFloat(paymentData.referenceValue.replace(/[^\d,-]/g, '').replace(',', '.')) || 0;
    } else {
      subtotal = paymentData.referenceValue;
    }
    
    const financialDiscountValue = (subtotal * paymentData.discount) / 100;
    const total = subtotal - financialDiscountValue;
    const cashValue = (total * paymentData.downPayment) / 100;

    setSummary({
      subtotal,
      financialDiscount: financialDiscountValue,
      total,
    });

    // Gerar parcelas
    generateInstallments(total, cashValue);
  }, [paymentData.referenceValue, paymentData.discount, paymentData.downPayment, generateInstallments]);

  // Função para gerar resultado em texto
  const generateResult = () => {
    let result = '';
    const referenceValue = typeof paymentData.referenceValue === 'string' 
      ? parseFloat(paymentData.referenceValue.replace(/[^\d,-]/g, '').replace(',', '.')) || 0
      : paymentData.referenceValue;
    
    result += `Valor: ${formatCurrency(referenceValue)} | Forma: ${paymentData.paymentMethod} | Parcelas: ${paymentData.installments}\n`;
    result += `Entrada: ${paymentData.downPayment}% | Desconto: ${paymentData.discount}% | Data: ${formatDateBR(paymentData.entryDate)}\n\n`;
    result += `Subtotal: ${formatCurrency(summary.subtotal)} | Total: ${formatCurrency(summary.total)}\n\n`;

    // Adicionar parcelas com quebra de linha
    installments.forEach((installment) => {
      result += `${installment.description}: ${formatCurrency(installment.value)} - ${formatDateBR(installment.dueDate)} - ${installment.paymentMethod}\n`;
    });

    setResultText(result);
    setShowResult(true);
  };

  // Função para copiar resultado
  const copyResult = async () => {
    try {
      await navigator.clipboard.writeText(resultText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000); // Remove a mensagem após 2 segundos
    } catch (err) {
      console.error('Erro ao copiar:', err);
    }
  };

  // Função para limpar formulário
  const clearForm = () => {
    setPaymentData({
      referenceValue: 0,
      paymentMethod: 'PARCELADO',
      installments: 0,
      entryDate: new Date().toISOString().split('T')[0],
      downPayment: 100,
      discount: 0,
      installmentInterval: 30,
      firstInstallmentTerm: 0,
      dueDay: 0,
    });
    setInstallments([]);
    setSummary({ subtotal: 0, financialDiscount: 0, total: 0 });
    setShowResult(false);
  };


  // Recalcular quando os dados mudarem
  useEffect(() => {
    const referenceValue = typeof paymentData.referenceValue === 'string' 
      ? parseFloat(paymentData.referenceValue.replace(/[^\d,-]/g, '').replace(',', '.')) || 0
      : paymentData.referenceValue;
    
    if (referenceValue > 0) {
      calculatePayment();
    }
  }, [paymentData, calculatePayment]);

  return (
    <div className="min-h-screen bg-white py-4">
      <div className="max-w-4xl mx-auto px-4">
        <Card className="border border-gray-200">
          <CardContent className="p-4 space-y-4">
            <PaymentForm
              paymentData={paymentData}
              setPaymentData={setPaymentData}
              formatCurrency={formatCurrency}
            />

            <InstallmentsTable
              installments={installments}
              setInstallments={setInstallments}
              formatCurrency={formatCurrency}
              formatDateBR={formatDateBR}
            />

            <SummarySection summary={summary} formatCurrency={formatCurrency} />

            <div className="flex flex-wrap justify-center gap-2 pt-3 border-t border-gray-200">
              <Button variant="outline" onClick={generateResult} size="sm" className="border-gray-300 text-black hover:bg-gray-50">
                Gerar Resultado
              </Button>
              {showResult && (
                <Button variant="outline" onClick={copyResult} size="sm" className="border-gray-300 text-black hover:bg-gray-50">
                  {copied ? 'Copiado!' : 'Copiar'}
                </Button>
              )}
              <Button variant="outline" onClick={clearForm} size="sm" className="border-gray-300 text-black hover:bg-gray-50">
                Limpar
              </Button>
            </div>

            {showResult && (
              <ResultSection resultText={resultText} />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}